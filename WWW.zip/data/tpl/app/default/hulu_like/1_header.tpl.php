<?php defined('IN_IA') or exit('Access Denied');?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">

   <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
  <title><?php  echo $make['make_web_title'];?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo MODULE_URL;?>template/mobile/style/public.css">

<?php  echo register_jssdk(false);?>
<script type="text/Javascript" src="<?php echo MODULE_URL;?>public/jquery.min.js"></script>

 </head>
 <body>
  

