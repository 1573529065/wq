<?php defined('IN_IA') or exit('Access Denied');?><style>
#picture_upload{float:left;width:100%;height:auto;margin:10px auto;}
.picture_upload_add{float:left;width:25%;height:120px;}
.picture_upload_add_pic{width:60px;height:80px;margin:10px auto;background-image:url("<?php echo MODULE_URL;?>public/images/upload.png");background-size:100% 100%;}
.picture_upload_add_p{width:100%;height:20px;margin:0px auto;text-align:center;line-height:20px;font-size:12px;color:#999;overflow:hidden;}
.picture_upload_yulan{float:left;width:45%;height:200px;}
.picture_upload_yulan_pic{width:100%;height:200px;margin:10px auto;position:relative;}
.picture_upload_yulan_pic img{width:100%;height:100%;}
.picture_upload_yulan_remove{width:20px;height:20px;background-color:#EEE;background-image:url("<?php echo MODULE_URL;?>public/images/remove.png");background-size:100% 100%;position:absolute;top:-10px;right:-10px;z-index:100;}
.picture_upload_yulan_p{width:100%;height:20px;margin:0px auto;text-align:center;line-height:20px;font-size:12px;overflow:hidden;}
          .button-selectimg{text-decoration:none;}
          .button-selectimg[class="button-selectimg"],input[type='submit']{color:#00A2D4;padding:4px 6px;border:1px dashed #00A2D4;border-radius:2px;}
          .input-file{margin:5% 10%;}
         input[id="avatval"]{padding:3px 6px;padding-left:10px;border:1px solid #E7EAEC;width:50%;height:25px;line-height:25px;border-left:3px solid #3FB7EB;background:#FAFAFB;border-radius:2px;}
         input[type='file']{border:0px;display:none;}
</style>
    <div class="input-file" style="width:80%">
         <form action="<?php echo $this->createMobileUrl('download_video',array('type'=>'add','picture_type'=>($picture_type ? $picture_type : 'show')));?>" method="post" enctype="multipart/form-data">
             <input type="text" id="avatval" placeholder="上传视频...." readonly="readonly" style="vertical-align: middle;"/>
             <input type="file" name="avatar" id="avatar"/>
             <a href="javascript:void(0);" class="button-selectimg" id="avatsel">上传视频</a>
             <input type="submit" name="" id="" value="提交" />
         </form>
    </div>
<div id="picture_upload">

    <?php  if(is_array($picture)) { foreach($picture as $key => $picture) { ?>
    <div class="picture_upload_yulan">
        <div class="picture_upload_yulan_pic">
	   <video src="<?php  echo $_W['attachurl'];?><?php  echo $picture['picture_url'];?>" width="150" height="200" controls></video>
            <div class="picture_upload_yulan_remove"><input type="hidden" name="picture_id" value="<?php  echo $picture['picture_id'];?>"/></div>
        </div>
        <?php  if($picture['picture_pid']=="2") { ?>
        <div class="picture_upload_yulan_p" style="color:red;">审核中</div>
        <?php  } else if($picture['picture_pid']=="3") { ?>
        <div class="picture_upload_yulan_p" style="color:#09BB07;">已通过</div>
        <?php  } ?>
    </div>
    <?php  } } ?>
</div>

<script>
//删除照片开始
    $(document).ready(function () {
	   $("#avatsel").click(function(){
                 $("input[type='file']").trigger('click');
             });
             $("#avatval").click(function(){
                 $("input[type='file']").trigger('click');
            });
             $("input[type='file']").change(function(){
                 $("#avatval").val($(this).val());
             });
        $(".picture_upload_yulan_remove").click(function () {
            var picture_id = $(this).children().val();
            $.post("<?php  echo $this->createMobileUrl('download_video',array('type'=>'del'));?>",
                    {
                        picture_id: picture_id,ptype:'<?php echo $picture_type ? $picture_type : 'show';?>'
                    },
                    function (data, status) {
                        if (data == 1) {
                            window.location.reload();
                        }
                    });
        });
    });
//删除照片结束

    wx.ready(function () {
        $(document).ready(function () {
     

//选择照片结束
//上传照片开始
            function uploadImage(arr) {
                for (var i = 0; i < arr.length; i++) {
                    wx.uploadImage({
                        localId: arr[i], // 需要上传的图片的本地ID，由chooseImage接口获得
                        isShowProgressTips: 1, // 默认为1，显示进度提示
                        success: function (res) {
                            var serverId = res.serverId; // 返回图片的服务器端ID
                            downloadImage(serverId);
                        }
                    });
                }
            }
//上传照片结束
//下载图片开始
//下载图片结束

        });
    });
</script>
