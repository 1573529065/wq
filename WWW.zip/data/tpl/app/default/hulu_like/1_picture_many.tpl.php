<?php defined('IN_IA') or exit('Access Denied');?><style>
#picture_many{float:left;width:92%;height:auto;margin:0px 4%;}
.picture_many_style{float:left;width:28%;height:100px;}
.picture_many_style_add{width:80px;height:80px;margin:10px auto 10px 0px;}
.picture_many_style_add img{width:100%;height:100%;}

.picture_many_style_yulan{width:80px;height:80px;margin:10px auto;position:relative;}
.picture_many_style_yulan img{width:100%;height:100%;}

.picture_many_style_yulan_remove{width:20px;height:20px;background-color:#3cb5f6;border-radius:5px;
position:absolute;top:-8px;right:-8px;z-index:100;}
.picture_many_style_yulan_remove img{width:100%;height:100%;}
</style>

<div id="picture_many">

<div class="picture_many_style"><div class="picture_many_style_add"><img src="<?php echo MODULE_URL;?>public/images/upload.png"/></div></div>

<!--
<div class="picture_many_style">
<div class="picture_many_style_yulan">
<img src="<?php echo MODULE_URL;?>public/images/upload.png"/>
<div class="picture_many_style_yulan_remove"><img src="<?php echo MODULE_URL;?>public/images/remove.png"/></div>
</div>
</div>
-->

</div>

<script>
wx.ready(function(){
	$(document).ready(function(){



	//选择照片开始
	  var images = {
    localId: [],
    serverId: []
  };
  document.querySelector('.picture_many_style_add').onclick = function () {
    wx.chooseImage({
		    sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
    sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有

      success: function (res) {
        images.localId = res.localIds;
        var h=res.localIds.length;
		if(h>=9){
			alert("最多只能上传9张图片");return false;
		}
		uploadImage(images.localId);
      }
    });
  };

	//选择照片结束

	//上传照片开始
	function uploadImage(e){
		/*
    if (images.localId.length == 0) {
      alert('请先使用 chooseImage 接口选择图片');
      return;
    }
	*/
    var i = 0, length = e.length;
    images.serverId = [];
    function upload() {
      wx.uploadImage({
        localId:e[i],
        success: function (res) {
          i++;
          //alert('已上传：' + i + '/' + length);
          images.serverId.push(res.serverId);
		  downloadImage(res.serverId);
		  
          if (i < length) {
            upload();
          }
        },
        fail: function (res) {
          alert(JSON.stringify(res));
        }
      });
    }
    upload();
  };
	//上传照片结束

	//下载照片开始
	function downloadImage(l){
	$.post("<?php  echo $this->createMobileUrl('download',array('city'=>$city,'type'=>'talk'));?>",
    {
		serverId:l,
     
      
    },
    function(data,status){
		var s='<div class="picture_many_style"><div class="picture_many_style_yulan"><img src="<?php  echo $_W["attachurl"];?>'+data+'"/><input type="hidden" name="picture[]" value="'+data+'"/><div class="picture_many_style_yulan_remove"><img src="<?php echo MODULE_URL;?>public/images/remove.png"/></div></div></div>';
      $("#picture_many").append(s);

	  	$(".picture_many_style_yulan_remove").click(function(){
  $(this).parent().parent().hide();
  //删除照片开始
  $.post("<?php  echo $this->createMobileUrl('download',array('city'=>$city,'type'=>'del'));?>",
    {
		picture_url:data,
     
    });
  //删除照片结束
  });

    });
	}
	//下载照片结束

});
});
</script>