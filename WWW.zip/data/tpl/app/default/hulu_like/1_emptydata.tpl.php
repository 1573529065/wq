<?php defined('IN_IA') or exit('Access Denied');?><style type="text/css">
#emptydata{width:100%;height:100px;margin:10px auto;
text-align:center;line-height:100px;font-size:16px;color:#999;overflow:hidden;}
</style>

<div id="emptydata">哎呀，没有数据啦！</div>