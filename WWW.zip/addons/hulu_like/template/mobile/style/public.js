$(document).ready(function(){
  $(".page_float_p_1,.page_float_off").click(function(){
  $("#page_float").hide();
  });





});