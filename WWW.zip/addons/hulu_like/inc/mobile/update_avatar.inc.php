<?php

/*
	$avatar = array('avatar' => trim($_GPC['avatar']));
	if (mc_update($_W['member']['uid'], $avatar)) {
		message('ͷ�����óɹ���', referer(), 'success');
	}

	*/
echo '123';


?>